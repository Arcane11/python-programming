### DO NOT REMOVE THIS
from typing import List
### DO NOT REMOVE THIS
class Solution:
    def myPow(self, x: float, n: int) -> float:
        return x**n
