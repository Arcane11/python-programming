### DO NOT REMOVE THIS
from typing import List
### DO NOT REMOVE THIS
class Solution:
    def findMin(self, nums: List[int]) -> int:
        return min(nums)
